export interface IconsType {
    classes?: string
    size?: number
}