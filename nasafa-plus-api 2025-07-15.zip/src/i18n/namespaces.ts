export default [
    'login', 'drawer', "dashboard", 'user-management/user', 'user-management/role', "user-management/permission", "container-management/group",
    "container-management/type", "container-management/container", "truck-management/group", "truck-management/type", "truck-management/truck",
    'client-management/group', "client-management/client", "client-management/type", "maintenance-management/group",
    "maintenance-management/type", "maintenance-management/maintenance", "contract-management/group", "contract-management/type",
    "contract-management/contract", "system-management/system-settings", "system-management/user-settings", "notifications"
];
