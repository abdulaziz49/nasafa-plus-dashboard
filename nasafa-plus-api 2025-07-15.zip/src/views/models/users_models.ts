export interface userGroupModel {
    id: number,
    group_name: string,
    group_description: string,
    user_creator: number
}