import ErrorsTemplate from "../../components/templates/errors_template.tsx";

const View404 = () => {
    return(
        <ErrorsTemplate>
            <h1>404</h1>
        </ErrorsTemplate>
    )
}

export default View404