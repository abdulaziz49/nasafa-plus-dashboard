const DrawerButtonSkeleton = () => {
    return (
        <label
            className="skeleton size-10 lg:hidden fixed top-3 start-3 z-2">
        </label>
    )
}

export default DrawerButtonSkeleton