export default function  CircleLoading ()  {
    return (
        <div className='w-screen h-screen flex justify-center items-center'>
            <span className="loading loading-spinner text-primary"></span>
        </div>
    )
}