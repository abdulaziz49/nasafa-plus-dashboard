import type {UserRole} from "../../models/users/user_role_model.ts";

export type DataGridGenericType = UserRole