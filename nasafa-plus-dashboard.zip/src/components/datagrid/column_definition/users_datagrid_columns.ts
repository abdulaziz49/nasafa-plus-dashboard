export const userGroupTableColumn: object[] = [
    {headerName: "ID",field: "id"},
    {headerName: "Name",field: "roleName"},
    {headerName: "Description",field: "description"},
    {headerName: "User",field: "userCreatorId"},
]