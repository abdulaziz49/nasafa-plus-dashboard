const supportedLangs = {
    ar: "العربية",
    en: "English",
};

export default supportedLangs